#### Issue details
_Please describe the problem, or desired feature_

#### Version
_What version was the issue encountered with_


#### Board type
_What type of the OSD board you are using?_

#### How "canonical" OSD firmware works?
[  ] Works fine
[  ] The same bug
[  ] Not applicable
[  ] Not tested

#### TLOG and OSD
_Please provide a links to a relevant screenshot/video, TLOG and OSD files that show the issue_

