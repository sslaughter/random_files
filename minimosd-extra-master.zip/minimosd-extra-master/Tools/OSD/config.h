namespace OSD {
 
  partial class OSD {
 

  }
 
}
