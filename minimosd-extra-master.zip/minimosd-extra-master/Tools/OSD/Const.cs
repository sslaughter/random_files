using System;

namespace OSD {
	public class Const {
		public Const() {
		}
	}
}

